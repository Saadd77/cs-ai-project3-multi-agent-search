# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState: GameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState: GameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        # Start with the base score
        score = successorGameState.getScore()

        # Reward getting closer to food
        foodList = newFood.asList()
        if foodList:
            minFoodDist = min([util.manhattanDistance(newPos, food) for food in foodList])
            score += 10.0 / minFoodDist

        # Penalize getting too close to active ghosts
        for ghostState in newGhostStates:
            ghostPos = ghostState.getPosition()
            # If the ghost is NOT scared
            if ghostState.scaredTimer == 0: 
                dist = util.manhattanDistance(newPos, ghostPos)
                if dist > 0:
                    score -= 10.0 / dist
                else:
                    return -float('inf') # Guaranteed death, avoid at all costs
                    
        return score

def scoreEvaluationFunction(currentGameState: GameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"
        def minimax(agentIndex, depth, state):
            # Terminal states or max depth reached
            if depth == self.depth or state.isWin() or state.isLose():
                return self.evaluationFunction(state)
            
            # Pacman (Max layer)
            if agentIndex == 0: 
                return max(minimax(1, depth, state.generateSuccessor(agentIndex, action)) for action in state.getLegalActions(agentIndex))
            
            # Ghosts (Min layer)
            else: 
                nextAgent = agentIndex + 1
                nextDepth = depth
                if nextAgent == state.getNumAgents():
                    nextAgent = 0
                    nextDepth += 1
                return min(minimax(nextAgent, nextDepth, state.generateSuccessor(agentIndex, action)) for action in state.getLegalActions(agentIndex))
        
        # Root caller loop
        bestAction = Directions.STOP
        bestScore = -float('inf')
        for action in gameState.getLegalActions(0):
            score = minimax(1, 0, gameState.generateSuccessor(0, action))
            if score > bestScore:
                bestScore = score
                bestAction = action
                
        return bestAction

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        def alphabeta(agentIndex, depth, state, alpha, beta):
            if depth == self.depth or state.isWin() or state.isLose():
                return self.evaluationFunction(state)
            
            if agentIndex == 0: # Pacman (Max)
                v = -float('inf')
                for action in state.getLegalActions(agentIndex):
                    v = max(v, alphabeta(1, depth, state.generateSuccessor(agentIndex, action), alpha, beta))
                    if v > beta: return v # Prune
                    alpha = max(alpha, v)
                return v
                
            else: # Ghosts (Min)
                v = float('inf')
                nextAgent = agentIndex + 1
                nextDepth = depth
                if nextAgent == state.getNumAgents():
                    nextAgent = 0
                    nextDepth += 1
                for action in state.getLegalActions(agentIndex):
                    v = min(v, alphabeta(nextAgent, nextDepth, state.generateSuccessor(agentIndex, action), alpha, beta))
                    if v < alpha: return v # Prune
                    beta = min(beta, v)
                return v

        # Root caller loop (Updates Alpha properly!)
        bestAction = Directions.STOP
        bestScore = -float('inf')
        alpha = -float('inf')
        beta = float('inf')
        
        for action in gameState.getLegalActions(0):
            score = alphabeta(1, 0, gameState.generateSuccessor(0, action), alpha, beta)
            if score > bestScore:
                bestScore = score
                bestAction = action
            alpha = max(alpha, bestScore) # Crucial: update alpha at the root
            
        return bestAction

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        def expectimax(agentIndex, depth, state):
            if depth == self.depth or state.isWin() or state.isLose():
                return self.evaluationFunction(state)
            
            if agentIndex == 0: # Pacman (Max layer)
                return max(expectimax(1, depth, state.generateSuccessor(agentIndex, action)) for action in state.getLegalActions(agentIndex))
                
            else: # Ghosts (Expectation layer)
                nextAgent = agentIndex + 1
                nextDepth = depth
                if nextAgent == state.getNumAgents():
                    nextAgent = 0
                    nextDepth += 1
                    
                actions = state.getLegalActions(agentIndex)
                # Return the average score for random ghosts
                return sum(expectimax(nextAgent, nextDepth, state.generateSuccessor(agentIndex, action)) for action in actions) / float(len(actions))
        
        # Root caller loop
        bestAction = Directions.STOP
        bestScore = -float('inf')
        for action in gameState.getLegalActions(0):
            score = expectimax(1, 0, gameState.generateSuccessor(0, action))
            if score > bestScore:
                bestScore = score
                bestAction = action
                
        return bestAction

def betterEvaluationFunction(currentGameState: GameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    pos = currentGameState.getPacmanPosition()
    food = currentGameState.getFood()
    ghostStates = currentGameState.getGhostStates()
    scaredTimes = [ghostState.scaredTimer for ghostState in ghostStates]
    capsules = currentGameState.getCapsules()

    score = currentGameState.getScore()
    
    # 1. Heavily reward eating food
    foodList = food.asList()
    if foodList:
        minFoodDist = min([util.manhattanDistance(pos, f) for f in foodList])
        score += 10.0 / minFoodDist
    
    # Massive penalty for remaining food & capsules (forces him to clear the board fast)
    score -= 10 * len(foodList)
    score -= 20 * len(capsules)
    
    # 2. Ghost Hunting Logic
    for i, ghost in enumerate(ghostStates):
        dist = util.manhattanDistance(pos, ghost.getPosition())
        if scaredTimes[i] > 0:
            # If ghost is scared, strongly encourage eating them for big points
            if dist > 0:
                score += 200.0 / dist 
        else:
            # If ghost is dangerous, keep distance
            if dist > 0:
                score -= 10.0 / dist
            else:
                return -float('inf') # Guaranteed death
                
    return score

# Abbreviation
better = betterEvaluationFunction
